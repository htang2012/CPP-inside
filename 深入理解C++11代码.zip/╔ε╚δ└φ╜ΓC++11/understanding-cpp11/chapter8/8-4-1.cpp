#include <iostream>
using namespace std;

int main(){
    cout << R"(hello,\n
         world)" << endl;
    return 0;
}
