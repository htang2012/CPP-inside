#if __cplusplus < 201103L
    #error "should use C++11 implementation"
#endif
