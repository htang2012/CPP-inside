static_assert(sizeof(int) == 8, "This 64-bit machine should follow this!");

int main() { return 0; }
