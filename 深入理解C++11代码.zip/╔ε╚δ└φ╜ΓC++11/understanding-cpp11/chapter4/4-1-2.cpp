template <int i> class X {};
X<(1 >> 5)> x ; 
