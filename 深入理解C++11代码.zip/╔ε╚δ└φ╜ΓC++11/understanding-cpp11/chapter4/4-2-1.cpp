#include <iostream>
using namespace std;

int main() {
    auto name = "world.\n";
    cout << "hello, " << name;
}

