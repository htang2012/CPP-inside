int foo() 
{
    int* px = (void*)0;
    int* py = nullptr;
}
